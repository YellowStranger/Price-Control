import asyncio
import asyncpg
import json

connections = {}
maxlen = 524288
db_host = '127.0.0.1'
db_port = 5432
db_user = 'price_user'
db_name = 'price_control'
db_password = 'test'

async def get_user(reader):
    received = await reader.read(maxlen)
    return json.loads(received.decode())

async def handler(reader, writer):
    global connections

    user_data = await get_user(reader)
    
    if user_data['event'] == 'login':
        db = await asyncpg.connect(host=db_host, port=5432, user=db_user, database=db_name, password=db_password)
        db_request = await db.fetch(
            'select email, password from users'
        )
        await db.close()
        users_list = list(map(tuple, db_request))
        
        for users in users_list:
            username, password = users[0], users[1]
            if user_data['email'] == username and user_data['password'] == password:
                data_to_send = {'correct': True}
                writer.write(json.dumps(data_to_send).encode())
                await writer.drain()
            else:
                data_to_send = {'correct': False}
                writer.write(json.dumps(data_to_send).encode())
                await writer.drain()
                
    writer.close()
    await writer.wait_closed()


async def main():
    server = await asyncio.start_server(handler, '127.0.0.1', 5310, limit=2097152)
    async with server:
        await server.serve_forever()
    

asyncio.run(main())