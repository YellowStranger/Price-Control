import asyncio
import json

maxlen = 524288
server = '127.0.0.1'

class Socket:
    
    async def start(self, email, password):
        
        
        self.reader, self.writer = await asyncio.open_connection(server, port=5310)
        data_to_send = {'event': 'login', 'email': email, 'password': password}
        self.writer.write(json.dumps(data_to_send).encode())
        await self.writer.drain()
        received = await self.reader.read(maxlen)
        received_data = json.loads(received.decode())
        if received_data['correct']:
            # для проверки правильности ввода логина/пароля в основной программе
            self.correct = True
        else:
            self.correct = False